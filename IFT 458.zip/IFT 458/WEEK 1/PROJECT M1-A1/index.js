
function add(val1, val2){
    return val1 + val2;
}

//calling a function
let result = add(10, 100.5);

//to print the value
console.log(result);