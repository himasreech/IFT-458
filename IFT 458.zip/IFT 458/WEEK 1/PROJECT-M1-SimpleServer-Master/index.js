const data = require('./data/data.json');

//console.log(data);

//console.dir(data);
//console.error(data);

data.forEach(function(item){
    console.log('*'.repeat(20));
    console.log(item);
    item.IFT458='Summer';// we can't add dynamic values in java in this position
    item.payment = function(val){
        return item.credits * val;
    }

})

data.forEach(function(item){
    console.log('*'.repeat(20));
    console.log(item);

})

//to get specific value of items
//data.forEach(function(item){
//    const {id, image} = item;
 //   console.log(`id = ${id}`);
  //  console.log(`image = ${image}`);

//})